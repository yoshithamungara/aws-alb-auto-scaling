# AWS Application Load Balancer (ALB) with Auto Scaling Group (ASG)

Deploy a highly available web application using EC2, ALB and Auto Scaling Group.

## AWS Services
- EC2
- Application Load Balancer
- Auto Scaling Group
- Launch Template
- VPC
- Security Groups
- CloudWatch

## Deployment
1. Launch EC2 and install Nginx.
2. Create Launch Template.
3. Create ASG.
4. Configure ALB and Target Group.
5. Access the app through the ALB DNS.

## Learning Outcomes
High availability, scalability, load balancing, auto scaling.
